export const reference_id_error = "ID Error.";
export const reference_valid_error = "Product reference ID must be integer.";
export const input_unit_error = "Please select Quantity or Weight.";
export const input_unit_select_error = "Please select correct Quantity or Weight.";