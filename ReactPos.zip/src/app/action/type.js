/**
 *  @author Puffer
 *  @created at 12/03 2021
 *  @updated at 12/04 2021
 * 
 * **/

export const POS_BUTTON_CLICK = "pos_button_click";
export const POS_INPUT_METHOD = "pos_input_method_number";
export const POS_UPDATE_COMMENT = "pos_update_comment";
export const POS_UPDATE_LEFT = "pos_update_left";
export const POS_UPDATE_TOP_DATA = "post_update_top_data";